# SourceInsightTheme
Source Insight 4 Theme, Sublime style
![Sublime style theme](./SI_theme_sublime.png)
# Installation
Source Insight -> Option -> Load Configuration
