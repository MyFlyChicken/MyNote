# Monokai theme For Source Insight

## Screenshot
the Monokai color theme for Source Insight, and here is the screenshots:

![](imgs/example0.png)
![](imgs/example1.png)
![](imgs/example2.png)

## install
in Source Insight:
1. select menu "Options"---"visual theme" ---"Manage Visual themes"
2. import the xml file in this repo
3. select the Monokai theme in Source Ingisht
4. enjoy your new color theme